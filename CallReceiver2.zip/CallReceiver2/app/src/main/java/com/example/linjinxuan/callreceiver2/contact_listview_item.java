package com.example.linjinxuan.callreceiver2;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CursorAdapter;
import android.widget.ListAdapter;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class contact_listview_item extends AppCompatActivity {
    TextView tvName;
    private AdapterView lvContacts;
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_listview_item);
    }
    private Cursor getContacts() {
        Uri contactsUri = ContactsContract.Contacts.CONTENT_URI;
        String[] columns = {
                ContactsContract.Contacts._ID,
                ContactsContract.Contacts.DISPLAY_NAME
        };
        String sortOrder = ContactsContract.Contacts.DISPLAY_NAME;
        return getContentResolver().query(
                contactsUri, columns, null, null, sortOrder);
    }


    private Cursor getPhones(long id) {
        Uri phoneUri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
        String[] columns = {
                ContactsContract.CommonDataKinds.Phone.TYPE,
                ContactsContract.CommonDataKinds.Phone.NUMBER};
        String selection =
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ? ";
        String[] selectionArgs = {String.valueOf(id)};
        return getContentResolver().query(
                phoneUri, columns, selection, selectionArgs, null);
    }

    private ListAdapter getContactListAdapter() {
        Cursor cursor = getContacts();
        String[] columns = {ContactsContract.Contacts.DISPLAY_NAME
        };
        int[] textViewIds = {R.id.tvName};
        return new SimpleCursorAdapter(
                this, R.layout.activity_contact_listview_item,
                cursor, columns, textViewIds, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);
    }

    private void showContacts() {
        lvContacts.setAdapter(getContactListAdapter());
        lvContacts.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent,
                                    View view, int position, long id) {
                String text = "";
                String name = ((TextView) findViewById(R.id.tvName)).getText().toString();
                text += name;
                Cursor phones = getPhones(id);
                if (phones.getCount() <= 0) {
                    text += "\n" + getString(R.string.msg_PhoneNoNotFound);
                    Toast.makeText(context, text,Toast.LENGTH_SHORT).show();
                    return;
                }
                while (phones.moveToNext()) {
                    int phoneTypeID = phones.getInt(
                            phones.getColumnIndex(ContactsContract
                                    .CommonDataKinds.Phone.TYPE));
                    String type = getString(ContactsContract.CommonDataKinds.Phone
                            .getTypeLabelResource(phoneTypeID));
                    String phoneNo = phones.getString(phones.getColumnIndex(
                            ContactsContract.CommonDataKinds
                                    .Phone.NUMBER));
                    text += "\n" + type + ":" + phoneNo;
                }
                Toast.makeText(context, text,Toast.LENGTH_SHORT).show();

            }
        });
    }
}
